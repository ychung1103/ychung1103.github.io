INCLUDE Irvine32.inc

.data

	input Dword 1000 DUP(?)
	Number byte "�`�@�n��J�X�ӼƦr? (max 1000) ", 0   ;<1000
        stdin byte "�п�J�@�ӭn�[�J�ƧǪ��Ʀr : ", 0	
	before byte "�Ƨǫe���ƦC : ", 0
	after byte "�Ƨǫ᪺�ƦC : ", 0
	inCount Dword ?
	left  dword 0
	right dword ?
        space byte " " ,0
 
.code

main PROC

	call inputNum
	mov inCount, ebx        ;save input count
	dec ebx 
	mov right, ebx          ; save right = count -1
	mov edx, offset before
	call WriteString
	call display	
	call crlf
	mov ebx, left           ;ebx���O����low
	mov edx, right          ;edx���O����high
	push ebx
	push edx
	call quicksort

        mov edx, offset after
	call WriteString
        call display
	exit
main ENDP

inputNum proc uses eax ecx edx esi edi 
        
	mov esi, offset input

	mov edx, offset Number
	call WriteString
	call ReadInt
        mov ecx, eax            ;��J�Ӽ�               
	mov ebx, eax
	mov edi,0               ;array index
input1:
	mov edx, offset stdin
	call WriteString
	call ReadInt
	mov [esi+edi],eax
	add edi,4                
	
	loop input1

ret
inputNum endP

quicksort proc
        
	push ebp
	mov ebp, esp
	add esp,0FFFFFFF8h    ;2 local variable [ebp-4] = i [ebp-8] = j
	mov esi,offset input      ;array
	mov ebx,[ebp+12]      ;left
	mov edx,[ebp+8]       ;right
	cmp ebx, edx
        jnl $endOfQuicksort    ;if (left< right),  otherwise  -> end

	mov [ebp-4],ebx       ;i=left
        mov edi,edx       
        inc edi
	mov [ebp-8],edi       ;j=right +1

        call divide           ;find i, j and exchange until i>=j

	mov ebx, [ebp+12]     ;ebx���O����left	
        mov edx,[ebp-8]
	dec edx               ;edx = j-1   
	push ebx
	push edx	 
        call quicksort        ;quick(list,left,j-1)

        mov ebx,[ebp-8]
	inc ebx               ;ebx = j+1   
	mov edx,[ebp+8]       ;right
	push ebx
	push edx	 
        call quicksort        ;quick(list,j+1,right)

$endOfQuicksort:
       	 mov esp,ebp
         pop ebp
         ret 12
	
quicksort EndP

divide proc
;;;;  find i, j and exchange until i>=j
        mov ebx,[ebp+12]
        mov eax, ebx               
        mov edi,4
	mul edi               ;eax = (left)*4 , pivot = [esi+eax]
 
$while:
         mov ecx,[ebp-4]      ;i

         call find_I	      ;do i++; while(list[i]<pivot);

	 mov [ebp-4], ecx     ; save i
	 mov ecx,[ebp-8]      ; load j

         call find_J	      ;do j--; while(list[j]>pivot);
	 
	 mov [ebp-8],ecx      ;save j
	 mov ecx, [ebp-8]
	 mov edi,[ebp-4]      ;i
	 cmp edi,ecx          ;if i < j
	 jnl $endofif
	 push edi
	 push ecx
	 call Interchange
	$endofif:
	
         mov edi,[ebp-4]      ;i
         mov ecx,[ebp-8]      ;j
         cmp edi,ecx
         jnl $endwhile
         jmp $while
        
$endwhile:
         mov edi,[ebp+12]     ;edi = left
         mov ecx,[ebp-8]      ;ecx = j
         push edi
	 push ecx
	 call InterChange
	 ret

divide endp

find_I proc
;;;;  do i++; while(list[i]<pivot);  
$while1:
  
	 push eax
	 mov eax,4
	 inc ecx              ; i++
	 mul ecx              ; eax = ecx *4	 
	 mov edi,[esi+eax]    ; edi = list[i] 
	 pop eax              ; eax = (left)*4

	 cmp edi,[esi+eax]    ; if list[i]<pivot
	 jnl $endwhile1 

	 jmp $while1
	 
$endwhile1:
	 ret
find_I endp

find_J proc
;;;;  do j--; while(list[j]>pivot);    
$while2:
  
	 push eax
	 mov eax,4
	 dec ecx             ; y--
	 mul ecx              ; eax = ecx *4	 
	 mov edi,[esi+eax]    ; edi = list[j] 
	 pop eax              ; eax = (left)*4

	 cmp edi,[esi+eax]    ; if list[j]>pivot
	 jng $endwhile2		 
	 jmp $while2

$endwhile2:
	ret
find_J endP


InterChange proc uses eax ebx ecx edi esi 
;interchange(a,b) performs t= list[a]; list[a] = list[b]; list[b] =t 
	 push ebp
	 mov ebp, esp
         mov edi,[ebp+12]     ;edi = �ninterchange���ƪ�array index, a
         mov ecx,[ebp+8]      ;ecx = �ninterchange���t�@�ƪ�array index, b

         mov esi,offset input
	 mov eax,4
	 mul edi
	 mov edi,eax           ;edi = 4*a

	 mov ebx, [esi+edi]   ;eax = list[a]

         mov eax,4
         mul ecx
	 mov ecx,eax          ;ecx = 4 * b
	 xchg ebx,[esi+ecx]   ;list[b] = list[a]
	 mov [esi+edi],ebx   ;list[a] = list[b]
	 
         pop ebp    
	 ret 8
InterChange endP

display proc uses eax ebx ecx edx esi
	mov ecx,inCount
	mov esi, offset input
	mov ebx ,4
L1:
        
        mov eax,[esi]
	call writeint 
        add esi,ebx
	mov edx,offset space
	call writestring
        loop L1
        ret
display endp

En